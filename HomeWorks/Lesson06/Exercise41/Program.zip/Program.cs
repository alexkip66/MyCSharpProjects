﻿/*
Задача 41: Пользователь вводит с клавиатуры M чисел. Посчитайте, сколько чисел больше 0 ввёл пользователь.
0, 7, 8, -2, -2 -> 2

1, -7, 567, 89, 223-> 3
*/
/*
// Вариант 1
Console.Write("Введите количество чисел, которые вы хотите ввести: ");
int n = Convert.ToInt32(Console.ReadLine());

int countPos = 0;

for (int i = 0; i < n; i++)
{
    Console.Write($"Введите число {i + 1}: ");
    double number = Convert.ToDouble(Console.ReadLine());

    if (number > 0)
        countPos++;
}

Console.WriteLine($"Количество чисел больше 0: {countPos}");

//Вариант 2
Console.WriteLine("Введите числа (для завершения введите пустую строку):");

int countPositive = 0;

while (true)
{
    Console.Write("Введите число: ");
    string input = Console.ReadLine();

    if (string.IsNullOrEmpty(input))
    {
        break; // Если введена пустая строка, завершаем ввод чисел
    }

    if (double.TryParse(input, out double number) && number > 0)
    {
        countPositive++;
    }
}

Console.WriteLine($"Количество чисел больше 0: {countPositive}");


//Вариант 3
Console.WriteLine("Введите числа (для окончания введите символ 'q'):");

int countPositive = 0;
string input;

while (true)
{
    Console.Write("Введите число: ");
    input = Console.ReadLine();

    if (input.ToLower() == "q")
    {
        break; // Выход из цикла при вводе символа 'q'
    }

    double number;
    if (double.TryParse(input, out number))
    {
        if (number > 0)
        {
            countPositive++;
        }
    }
    else
    {
        Console.WriteLine("Некорректный ввод. Введите число или 'q' для завершения.");
    }
}

Console.WriteLine($"Количество чисел больше 0: {countPositive}");
*/

//Вариант 4
Console.Write("Введите целые числа (через пробел): ");
int[] arr = Array.ConvertAll(Console.ReadLine()!.Split(' '), int.Parse);
int count = arr.Count(x => x > 0);
Console.WriteLine($"Количество чисел больше 0: {count}");